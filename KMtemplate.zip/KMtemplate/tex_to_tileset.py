#!/usr/bin/env python3
import argparse
import os
from PIL import Image
import math

def load_tex_list(tex_path):
    with open(tex_path, "r") as f:
        lines = [ln.strip() for ln in f.readlines() if ln.strip()]

    # Evo 2 format: starts with "Version"
    if lines[0].lower() == "version":
        print("Detected Evo 2 .tex format")

        # Header:
        # 0: Version
        # 1: 1
        # 2: textureCount,shadowTextureCount
        # 3: 84,383  (we want first number)
        header_counts = lines[3].split(",")
        texture_count = int(header_counts[0])
        print(f"Evo texture count: {texture_count}")

        data_lines = lines[4 : 4 + texture_count]

        tex_names = []
        for ln in data_lines:
            parts = ln.split(",")
            raw = parts[-1]  # third field
            base = os.path.splitext(raw)[0]
            tex_names.append(base)
        return tex_names

    # MTM2 format: first line is an integer count, then that many RAW names
    try:
        texture_count = int(lines[0])
        print("Detected MTM2 .tex format")
        print(f"MTM2 texture count: {texture_count}")

        data_lines = lines[1 : 1 + texture_count]
        tex_names = []
        for ln in data_lines:
            # e.g. MARKMTLX.RAW
            base = os.path.splitext(ln)[0]
            tex_names.append(base)
        return tex_names
    except ValueError:
        # Fallback: old simple-line format (if ever needed)
        print("Detected simple list .tex format (fallback)")
        return [os.path.splitext(ln)[0] for ln in lines if not ln.startswith("#")]


def build_tileset(tex_list, art_dir, out_path, tile_w=64, tile_h=64, sheet_w=256):
    tiles_per_row = sheet_w // tile_w
    total_tiles = len(tex_list)
    rows = math.ceil(total_tiles / tiles_per_row)

    sheet_h = rows * tile_h
    sheet = Image.new("RGBA", (sheet_w, sheet_h), (0, 0, 0, 0))

    for i, tex_name in enumerate(tex_list):
        png_path = os.path.join(art_dir, tex_name + ".png")

        if not os.path.exists(png_path):
            print(f"WARNING: Missing texture PNG: {png_path}")
            continue

        tile = Image.open(png_path).convert("RGBA")
        tile = tile.resize((tile_w, tile_h), Image.NEAREST)

        x = (i % tiles_per_row) * tile_w
        y = (i // tiles_per_row) * tile_h

        sheet.paste(tile, (x, y))

    sheet.save(out_path)
    print(f"Tileset written to {out_path} ({sheet_w}x{sheet_h})")


def main():
    parser = argparse.ArgumentParser(
        description="Build a 256px-wide tileset from MTM2 or Evo2 .tex + art directory"
    )
    parser.add_argument("tex", help=".tex file (MTM2 or Evo2)")
    parser.add_argument("art_dir", help="Directory containing PNG textures")
    parser.add_argument("out_png", help="Output tileset PNG path")
    args = parser.parse_args()

    tex_list = load_tex_list(args.tex)
    build_tileset(tex_list, args.art_dir, args.out_png)


if __name__ == "__main__":
    main()
