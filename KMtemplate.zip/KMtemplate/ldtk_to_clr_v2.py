import json
import struct
import sys
from pathlib import Path

# ------------------------------------------------------------
# CONFIGURATION
# ------------------------------------------------------------
# Expected world layout: 4x4 levels, each 64x64 tiles
LEVELS_X = 4
LEVELS_Y = 4
LEVEL_W = 64
LEVEL_H = 64

# Output CLR size: 256x256 tiles
CLR_W = LEVELS_X * LEVEL_W
CLR_H = LEVELS_Y * LEVEL_H


# ------------------------------------------------------------
# LOAD LDtk PROJECT
# ------------------------------------------------------------
def load_ldtk(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# ------------------------------------------------------------
# MERGE ALL TILE LAYERS IN A LEVEL
# ------------------------------------------------------------
def extract_merged_tile_grid(level):
    """
    Merges ALL tile layers in a level into a single 2D tile grid.
    Later (visually top) layers overwrite earlier ones.
    """
    tile_layers = [l for l in level["layerInstances"] if l["__type"] == "Tiles"]
    if not tile_layers:
        raise ValueError(f"Level {level['identifier']} has no tile layers.")

    # Use the first tile layer to get grid dimensions
    base = tile_layers[0]
    w = base["__cWid"]
    h = base["__cHei"]
    grid = [[0 for _ in range(w)] for _ in range(h)]

    # LDtk stores layers top-to-bottom; we want bottom-to-top for merging
    for layer in reversed(tile_layers):
        grid_size = layer["__gridSize"]

        for tile in layer["gridTiles"]:
            px = tile["px"][0]
            py = tile["px"][1]
            x = px // grid_size
            y = py // grid_size
            tile_id = tile["t"]  # tileset index

            if 0 <= x < w and 0 <= y < h:
                grid[y][x] = tile_id

    return grid


# ------------------------------------------------------------
# BUILD LEVEL GRID INDEX MAP FROM worldX/worldY
# ------------------------------------------------------------
def build_level_grid_index(levels):
    """
    Build mapping from level identifier to (gx, gy) by ranking worldX/worldY.
    Leftmost = gx 0, next = 1, etc. Same for gy (top to bottom).
    """
    xs = sorted({lvl["worldX"] for lvl in levels})
    ys = sorted({lvl["worldY"] for lvl in levels})

    if len(xs) != LEVELS_X or len(ys) != LEVELS_Y:
        raise ValueError(
            f"Expected {LEVELS_X} unique worldX and {LEVELS_Y} unique worldY, "
            f"got {len(xs)} and {len(ys)}."
        )

    x_index = {x: i for i, x in enumerate(xs)}
    y_index = {y: i for i, y in enumerate(ys)}

    grid_pos = {}
    for lvl in levels:
        gx = x_index[lvl["worldX"]]
        gy = y_index[lvl["worldY"]]
        grid_pos[lvl["identifier"]] = (gx, gy)

    return grid_pos


# ------------------------------------------------------------
# BUILD THE FULL 256x256 TILE ARRAY
# ------------------------------------------------------------
def stitch_levels(ldtk):
    world = [[0 for _ in range(CLR_W)] for _ in range(CLR_H)]
    levels = ldtk["levels"]

    expected_levels = LEVELS_X * LEVELS_Y
    if len(levels) != expected_levels:
        raise ValueError(f"Expected {expected_levels} levels, found {len(levels)}.")

    grid_pos = build_level_grid_index(levels)

    for level in levels:
        lvl_id = level["identifier"]
        gx, gy = grid_pos[lvl_id]

        grid = extract_merged_tile_grid(level)

        # Basic sanity check on grid size
        if len(grid) != LEVEL_H or any(len(row) != LEVEL_W for row in grid):
            raise ValueError(
                f"Level {lvl_id} grid size mismatch: "
                f"expected {LEVEL_W}x{LEVEL_H}, got {len(grid[0])}x{len(grid)}"
            )

        for y in range(LEVEL_H):
            for x in range(LEVEL_W):
                world_y = gy * LEVEL_H + y
                world_x = gx * LEVEL_W + x
                world[world_y][world_x] = grid[y][x]

    return world


# ------------------------------------------------------------
# WRITE CLR FILE
# ------------------------------------------------------------
def write_clr(path, tilemap):
    with open(path, "wb") as f:
        for y in range(CLR_H):
            # Flip vertically: LDtk top row -> MTM2 top row
            src_y = CLR_H - 1 - y
            for x in range(CLR_W):
                tile_id = tilemap[src_y][x] & 0xFF
                high_byte = 0x00  # type/depth = 0 for now
                f.write(struct.pack("<BB", tile_id, high_byte))



# ------------------------------------------------------------
# png sanity check
# ------------------------------------------------------------
from PIL import Image

def write_debug_png(path, tilemap):
    """
    Writes a 256x256 PNG where each pixel color is derived from the tile ID.
    This helps visually verify layer merging, stitching, and patterns.
    """
    img = Image.new("RGB", (CLR_W, CLR_H))
    pixels = img.load()

    for y in range(CLR_H):
        for x in range(CLR_W):
            t = tilemap[y][x] & 0xFF

            # Simple color mapping: spread tile IDs across RGB channels
            r = (t * 53) % 256
            g = (t * 97) % 256
            b = (t * 193) % 256

            pixels[x, y] = (r, g, b)

    img.save(path)
    print(f"Wrote debug PNG: {path}")


# ------------------------------------------------------------
# MAIN
# ------------------------------------------------------------
def main(ldtk_path, out_path):
    print("Loading LDtk project...")
    ldtk = load_ldtk(ldtk_path)

    print("Stitching levels and merging tile layers...")
    tilemap = stitch_levels(ldtk)

    print("Writing CLR file...")
    write_clr(out_path, tilemap)

    # Write debug PNG (unflipped)
    debug_path = str(Path(out_path).with_suffix(".png"))
    write_debug_png(debug_path, tilemap)

    size = Path(out_path).stat().st_size
    print(f"Done! Wrote {out_path} ({size} bytes)")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python ldtk_to_clr.py input.ldtk output.clr")
        sys.exit(1)

    main(sys.argv[1], sys.argv[2])
